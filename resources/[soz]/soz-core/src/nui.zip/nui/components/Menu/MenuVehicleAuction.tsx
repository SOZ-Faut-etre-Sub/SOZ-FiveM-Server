import { FunctionComponent } from 'react';

import { NuiEvent } from '../../../shared/event';
import { MenuType } from '../../../shared/nui/menu';
import { VehicleAuctionMenuData } from '../../../shared/vehicle/vehicle';
import { fetchNui } from '../../fetch';
import { MainMenu, Menu, MenuContent, MenuItemButton, MenuItemText, MenuTitle } from '../Styleguide/Menu';

type MenuVehicleAuctionProps = {
    data?: VehicleAuctionMenuData;
};

export const MenuVehicleAuction: FunctionComponent<MenuVehicleAuctionProps> = ({ data }) => {
    if (!data) {
        return null;
    }

    const onConfirm = () => {
        fetchNui(NuiEvent.VehicleAuctionBid, { name: data.name, auction: data.auction });
    };

    return (
        <Menu type={MenuType.Vehicle}>
            <MainMenu>
                <MenuTitle title="Enchère véhicules" />
                <MenuContent>
                    <MenuItemButton onConfirm={onConfirm} disabled={data.isAuctionDisable}>
                        Faire une enchère sur {data.auction.vehicle.name}
                    </MenuItemButton>
                    {data.isAuctionDisable && <MenuItemText>Les enchères sont fermées.</MenuItemText>}
                    {data.auction.bestBid && (
                        <MenuItemText>
                            Meilleure offre de {data.auction.bestBid.name} à ${data.auction.bestBid.price}
                        </MenuItemText>
                    )}
                    {!data.auction.bestBid && !data.isAuctionDisable && (
                        <MenuItemText>Mise à prix: ${data.auction.vehicle.price}</MenuItemText>
                    )}
                </MenuContent>
            </MainMenu>
        </Menu>
    );
};
