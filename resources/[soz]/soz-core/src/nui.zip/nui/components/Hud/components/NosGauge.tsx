import { FunctionComponent } from 'react';

import { useVehicle } from '../../../hook/data';
import NosIcon from '../../../icons/hud/vehicle/nos.svg';
import { useZoom } from '../hooks/useZoom';

export const NosGauge: FunctionComponent = () => {
    const containerSize = 100;

    const vehicle = useVehicle();
    const { nosPaddingTopSize, nosPaddingLeftSize, speedometerSize } = useZoom();

    if (vehicle.nosCount <= 0) {
        return null;
    }

    return (
        <div
            className="absolute"
            style={{
                marginTop: '-' + nosPaddingTopSize,
                marginLeft: '-' + nosPaddingLeftSize,
                width: speedometerSize,
                height: speedometerSize,
            }}
        >
            <svg viewBox="0 0 120 75" fill="none" xmlns="http://www.w3.org/2000/svg">
                <mask id="barMask">
                    <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M75.0746 7.69562C75.2315 9.06739 74.2467 10.3067 72.8749 10.4636C68.9673 10.9105 65.1031 11.6792 61.3219 12.7616C59.9945 13.1416 58.6104 12.3736 58.2304 11.0462C57.8504 9.71875 58.6185 8.33464 59.9458 7.95465C63.9914 6.79653 68.1259 5.97414 72.3067 5.49592C73.6785 5.33902 74.9177 6.32386 75.0746 7.69562ZM55.2636 12.075C55.787 13.3526 55.1755 14.8127 53.8978 15.336C52.0831 16.0794 50.2955 16.8988 48.5396 17.7935C46.7838 18.6881 45.0701 19.6527 43.4021 20.6839C42.2277 21.4099 40.6871 21.0464 39.961 19.872C39.235 18.6976 39.5985 17.157 40.7729 16.4309C42.5576 15.3276 44.3911 14.2956 46.2697 13.3384C48.1483 12.3812 50.061 11.5045 52.0025 10.7092C53.2802 10.1858 54.7402 10.7973 55.2636 12.075ZM37.3849 21.6675C38.2354 22.7551 38.0432 24.3263 36.9556 25.1769C33.8573 27.5997 30.9641 30.2741 28.3057 33.1727C27.3725 34.1903 25.791 34.2586 24.7735 33.3254C23.7559 32.3921 23.6876 30.8107 24.6208 29.7931C27.4651 26.6918 30.5606 23.8304 33.8755 21.2382C34.9632 20.3876 36.5344 20.5799 37.3849 21.6675ZM22.7814 35.7527C23.8952 36.5686 24.1367 38.133 23.3208 39.2468C22.1619 40.8288 21.0658 42.4616 20.0362 44.1418C19.0066 45.822 18.0494 47.5399 17.1659 49.2906C16.5439 50.5233 15.0404 51.0183 13.8078 50.3963C12.5751 49.7743 12.08 48.2708 12.702 47.0382C13.6472 45.165 14.6714 43.327 15.773 41.5293C16.8746 39.7316 18.0473 37.9847 19.2872 36.2921C20.1032 35.1782 21.6676 34.9368 22.7814 35.7527ZM12.5494 53.2733C13.8429 53.7562 14.4999 55.1963 14.017 56.4898C12.6412 60.1744 11.5717 63.9665 10.8196 67.8269C10.5555 69.1822 9.24282 70.0667 7.8876 69.8027C6.53237 69.5386 5.6478 68.226 5.91185 66.8707C6.71661 62.7403 7.86085 58.6831 9.33282 54.7409C9.81579 53.4474 11.2559 52.7903 12.5494 53.2733Z"
                        fill="white"
                    />
                </mask>

                <path
                    d="M9 70C13.4789 39.9995 34.5 10 75.5 7.5"
                    stroke="#fff"
                    strokeWidth="16"
                    strokeDasharray={containerSize}
                    strokeDashoffset={containerSize - containerSize * vehicle.nosLevel}
                    mask="url(#barMask)"
                />
            </svg>

            <div className="flex flex-row-reverse absolute w-10 -ml-7">
                <div className="relative">
                    {new Array(vehicle.nosCount).fill(0).map((_value, index) => {
                        return (
                            <NosIcon
                                className="absolute text-white h-[1.5rem]"
                                style={{
                                    right: 5 * index,
                                    opacity: 1.0 - (30 * index) / 100,
                                }}
                            />
                        );
                    })}
                </div>
            </div>
        </div>
    );
};
